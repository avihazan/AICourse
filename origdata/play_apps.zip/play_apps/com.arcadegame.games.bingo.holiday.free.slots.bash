�}q (X   titleqX   Bingo Holiday:Free Bingo GamesqX   iconqXe   https://lh3.googleusercontent.com/NrO3wSoRN68PYsZy_sVQR8EV1FV9CjoOtJ4NRyiHpmYK8_lEQ6iyaF4vH2IrFBHzxnAqX   screenshotsq]q(Xr   https://lh3.googleusercontent.com/SbPV5Opu3tMxNQ7OJ424bvfjZsGlFqZzKq36xA2Cdx_xj7873uQu1M5-bFbtEzHdQo0=w720-h310-rwqXq   https://lh3.googleusercontent.com/uu8KFk6ydbEWwI13wKX_GRlD9fSIOaYL0mm3c6GFX1v2kHkAdw1-ABdGBNnfnoBDEQ=w720-h310-rwqXr   https://lh3.googleusercontent.com/itEpwoJfW0rn77J0-P4wx8cBUA7xfCExU8uFkW-v0-5EeAury00gkAlZ22JmFdXdjdU=w720-h310-rwq	Xr   https://lh3.googleusercontent.com/Y_tmEd1pH43F3VU09L0GhtEFks5WCN88fIga3Pw2jaFpQLq8rPlw7nnfuHv8gIUafmk=w720-h310-rwq
Xq   https://lh3.googleusercontent.com/AOvw_7fgBvRCbjceeCMhnl6h5ysf-BCVM2sWCaSzAlYU42DetEX84XvKJ_cd8glpWA=w720-h310-rwqXs   https://lh3.googleusercontent.com/bWuFKL_AUgCxa62iWVjtSej_y2He9oAuhPmW00oyCuLfM6k5UNj1Nq8FrkrsYiZnb-Xf=w720-h310-rwqeX   videoqX)   https://www.youtube.com/embed/bOir4WHZz64qX   categoryq]qX   GAME_CASINOqaX   scoreqX   4.5qX	   histogramq}q(KMM�KM�6KM�KM�KM4
uX   reviewsqJuM X   descriptionqX�
  Welcome to Bingo Holiday, the #1 Classic & Special Bingo games!
FREE Bonus every hour! Really? Amazing! Explore 30+ appealing scenes, Travel, Bingo, Send and receive gifts with friends, Challenge events and find all the Epic Collections! Awesome! Let's Play Bingo and enjoy never-ending fun anywhere, anytime!
Exclusive Game Features:
★
Epic Power ups
Try your luck with the unique power ups: Daub Hint, Shield, Triple Free, Instant Bingo, Bombs, Double EXP, Double Coins, Flash Cooling...Use Power ups to WIN BIG!
★
Traditional Bingo 75
Play classic bingo games to have a fantastic exploration of World Tour with 20+ famous cities: New York, Paris, Dubai, London, Las Vegas, Tahiti, Bali, Santorini... Can’t wait to fly around the world and catch hold of the mysteries!
★
Special Bingo styles
Multiple Unique Bingo Styles bring you a bigger chance to win mega prizes! UK Jackpot, Slots Bingo, Blackout, Secret Garden, Dessert Master, Jackpot Blast, True Love...The greatly memorable scenes are right here waiting for you to experience!
★
Thrilling Daily Tournament
Play with friends and compete with thousands of real-time multiplayers in the tournament, get thrills of the ranking entertainment! Collect tournament Jewelry puzzles to compose your Super Crown!
★
Mystery Precious Collections
Travel the world and find mystery Collection items! Accomplish the epic collections with a lot of fun! Two ways to earn your exclusive treasures either from shadow cards or puzzle pieces.
★
Unprecedented Freebies
Sign in every day to collect your daily bonus and HOURLY freebies! Challenge with global players to win more rewards! The best choice to accompany with you and kill the long boring time!
★
Social Friends System
Sharing is caring! Send and receive the gifts & collections with your friends! Spread out your fortune and double the happiness!
Eager to enjoy Big Win, Huge Win, Quick Win, Double Win? Play Bingo Holiday: FREE Bingo Games RIGHT NOW!
Any suggestions? Having a fever for our Bingo app?
We would love to hear from you! You can reach us, the best Bingo games support team at:
customer.support@bingoholiday.xyz
Already a big fan of Bingo Holiday: FREE Bingo Games? Like us on Facebook to catch more information and grasp your freebies!
http://www.facebook.com/bingoholiday
Disclaimer:
*Bingo Holiday: FREE Bingo Games is intended for use for amusement purposes only. THERE IS NO REAL CASH PAYOUT YOU CAN EARN.
*Bingo Holiday: FREE Bingo Games does not offer real money gambling or an opportunity to win real money.
*Bingo Holiday: FREE Bingo Games uses Facebook as ads provider. Facebook and instagram likes wants to show ads relevant to you. For more information, please check https://m.facebook.com/ads/ad_choices.qX   description_htmlqB�  <b>Welcome to Bingo Holiday, the #1 Classic &amp; Special Bingo games!</b><br/>FREE Bonus every hour! Really? Amazing! Explore 30+ appealing scenes, Travel, Bingo, Send and receive gifts with friends, Challenge events and find all the Epic Collections! Awesome! Let's Play Bingo and enjoy never-ending fun anywhere, anytime!<br/><br/><b>Exclusive Game Features: </b><br/>★  <b>Epic Power ups</b><br/>Try your luck with the unique power ups: Daub Hint, Shield, Triple Free, Instant Bingo, Bombs, Double EXP, Double Coins, Flash Cooling...Use Power ups to WIN BIG!<br/>★ <b>Traditional Bingo 75</b><br/>Play classic bingo games to have a fantastic exploration of World Tour with 20+ famous cities: New York, Paris, Dubai, London, Las Vegas, Tahiti, Bali, Santorini... Can’t wait to fly around the world and catch hold of the mysteries!<br/>★ <b>Special Bingo styles</b><br/>Multiple Unique Bingo Styles bring you a bigger chance to win mega prizes! UK Jackpot, Slots Bingo, Blackout, Secret Garden, Dessert Master, Jackpot Blast, True Love...The greatly memorable scenes are right here waiting for you to experience!<br/>★ <b>Thrilling Daily Tournament</b><br/>Play with friends and compete with thousands of real-time multiplayers in the tournament, get thrills of the ranking entertainment! Collect tournament Jewelry puzzles to compose your Super Crown!<br/>★ <b>Mystery Precious Collections</b><br/>Travel the world and find mystery Collection items! Accomplish the epic collections with a lot of fun! Two ways to earn your exclusive treasures either from shadow cards or puzzle pieces. <br/>★ <b>Unprecedented Freebies</b><br/>Sign in every day to collect your daily bonus and HOURLY freebies! Challenge with global players to win more rewards! The best choice to accompany with you and kill the long boring time!<br/>★ <b>Social Friends System</b><br/>Sharing is caring! Send and receive the gifts &amp; collections with your friends! Spread out your fortune and double the happiness!<br/><br/>Eager to enjoy Big Win, Huge Win, Quick Win, Double Win? Play Bingo Holiday: FREE Bingo Games RIGHT NOW!<br/><br/>Any suggestions? Having a fever for our Bingo app?<br/>We would love to hear from you! You can reach us, the best Bingo games support team at:<br/>customer.support@bingoholiday.xyz<br/><br/>Already a big fan of Bingo Holiday: FREE Bingo Games? Like us on Facebook to catch more information and grasp your freebies!<br/>http://www.facebook.com/bingoholiday<br/><br/>Disclaimer:<br/>*Bingo Holiday: FREE Bingo Games is intended for use for amusement purposes only. THERE IS NO REAL CASH PAYOUT YOU CAN EARN.<br/>*Bingo Holiday: FREE Bingo Games does not offer real money gambling or an opportunity to win real money.<br/>*Bingo Holiday: FREE Bingo Games uses Facebook as ads provider. Facebook and instagram likes wants to show ads relevant to you. For more information, please check https://m.facebook.com/ads/ad_choices.qX   recent_changesqX   - Bugs fixed and optimization.qX   editors_choiceq�X   priceqX   0qX   freeq �X   iapq!�X   developer_idq"X   4682443305447149344q#X   updatedq$X   October 11, 2018q%X   sizeq&X   60Mq'X   installsq(X
   1,000,000+q)X   current_versionq*X   1.8.4q+X   required_android_versionq,X
   4.1 and upq-X   content_ratingq.]q/(X   Teenq0X   Simulated Gamblingq1eX	   iap_rangeq2X   $0.99q3X   $249.99q4�q5X   interactive_elementsq6]q7X!   Users Interact, Digital Purchasesq8aX	   developerq9X0   AE Magwin: Free Casino Slot Machines Bingo Gamesq:X   developer_emailq;X!   customer.android@bingoholiday.xyzq<X   developer_urlq=X   http://www.bingoholiday.xyzq>X   developer_addressq?X5   221 Boston Post Rd East, Suite 410
Marlborough MA
USAq@X   app_idqAX2   com.arcadegame.games.bingo.holiday.free.slots.bashqBX   urlqCX`   https://play.google.com/store/apps/details?id=com.arcadegame.games.bingo.holiday.free.slots.bashqDX   bidsqEM�vu.