�}q (X   titleqX
   Darts KingqX   iconqXe   https://lh3.googleusercontent.com/Vppfv2dsYUy-j8llMXegBX64tVDWjHFOwak63kXRo8uSaJwCU61FDTL18Cr3aLxwqukqX   screenshotsq]q(Xq   https://lh3.googleusercontent.com/rNghimHOhNrVkzl5JbGQE2IVdjvU_LzWMx3q5Jkl5FD9CLHTjK3S2iZFQDXJ3AxuSA=w720-h310-rwqXq   https://lh3.googleusercontent.com/dMlvYCV6ZmlvO8JEXSbsN2f9tqElrJ4Oz3vN6EeuEZD7AU5Ttiehr9g8Pf_95d26jQ=w720-h310-rwqXq   https://lh3.googleusercontent.com/9HCio-uJOCT1Xd35YG_LLZW7tF6g4JwOOYSwxrGcwBuiNpb50BrOCOzaDSR6c4p7Qg=w720-h310-rwq	Xs   https://lh3.googleusercontent.com/xt7X0_kY8fVPkGPZhs8PRZNlmS-RsEck7V9WerIzsZxzthfflSg9HfdgcY3oHOD92J5L=w720-h310-rwq
Xq   https://lh3.googleusercontent.com/naeV3gQOZUATIjcjNJGG8A9XLl0HgPNM5CaOb4TYIEmhs8QABYdy5swkGpyW-4z5fQ=w720-h310-rwqXq   https://lh3.googleusercontent.com/q9mUzlTYsbLpR_q5ldUEY2WooKGhDG8Pa2gN5UdTKCVcwCRiHyCD7DHiWlj-KYkPdQ=w720-h310-rwqXq   https://lh3.googleusercontent.com/lsJZ7-l5XFcgpJySMOQWxBQdNRK0qyQHFVyraGt2G8LgO0jn0dM4CZBRq8wZTWfhIg=w720-h310-rwqXs   https://lh3.googleusercontent.com/uVyZg4EXWSNoRjTv65kYy1wkQRT4TVAAbHJJ5OGLjHGfQ4YmJvweU_sQ_6939epGSgxO=w720-h310-rwqXs   https://lh3.googleusercontent.com/wsZYsOZkazSOf5oP951aGohTqahmrR5Ml8JYdU8CoMWvP_GwypLa4eaPHnhqoHZxNePF=w720-h310-rwqXq   https://lh3.googleusercontent.com/dOJeLRAdHbpPhwzh52P7W1vKH_FAO7U7hezRA9sZT0lJn37PWi4l_6YViIEEz0jp8Q=w720-h310-rwqXs   https://lh3.googleusercontent.com/5cHfcOX1Vxjz8rPmEHlGbiQ24Dw8zAuYkXa8EMMY5ZvjlIHjSzxVpymRt_GMAaUTyZPA=w720-h310-rwqXq   https://lh3.googleusercontent.com/GuFlzVvIBFc156S5EFvQvD6FpKQRgUUi0e9SWqLpdSaOMJw7mUP4Cua_4levoE72Jg=w720-h310-rwqXq   https://lh3.googleusercontent.com/KeL_OuravlJZdUZ-ypo_wbXWWsnxL6TV3M4cHuV1jTx6Yw_jOoPY1BTaILoyLu6UgQ=w720-h310-rwqXr   https://lh3.googleusercontent.com/tbSI8D71msCWmuer9wfaay1C2Xu-SXSKLqChYr0geHv7iaie7sWE2YcOv-GsJHSuDao=w720-h310-rwqXr   https://lh3.googleusercontent.com/MmpU8xkCoUGwsQYy1IEj_E5W6eB3R07pELHVZSPginnidBe9sv33QO7GPIsjUonk4VA=w720-h310-rwqXr   https://lh3.googleusercontent.com/zWk2zUm_5xyalueYjyW35fu4nzy-kOwGUq6_qSn0gjz39sUZgG8k45h30Vk2Xjemnqk=w720-h310-rwqXs   https://lh3.googleusercontent.com/67H9N6b4olCjGhEVNdTfFgPKUz7aCjlh6101GVTY-fLHzakYEQHGezKXgPftudwWP9WR=w720-h310-rwqXs   https://lh3.googleusercontent.com/oVbxxWNVzRs21_0EbfKflUTv4dDQit-0Otvclj90xnwL4bWKjQh6Rfvzq4tTyxmI7Dz-=w720-h310-rwqXr   https://lh3.googleusercontent.com/7LX12Nme2O-hMwy0MbpBBXYVO2SxfZ2Ug5nAzQdcDfgOQp6aSB4nDwsj5dD3ZbKpoa4=w720-h310-rwqXr   https://lh3.googleusercontent.com/-D_407QLKnSK0a_ZeboMvjmkpJ3GYu35YPpyH3WVosANyj460eL3yk0EqKeUYl5RjpI=w720-h310-rwqXq   https://lh3.googleusercontent.com/VWNdCrTRVI_kTylGujnTszJI8Cq-SPXOcIiOOv8iee0m7DavhyAxO9WzDm42o6VX9A=w720-h310-rwqeX   videoqX)   https://www.youtube.com/embed/qjrRXd9d7qwqX   categoryq]qX   GAME_SPORTSq aX   scoreq!X   4.3q"X	   histogramq#}q$(KMz�KM�>KM�KMtKM�uX   reviewsq%J� X   descriptionq&X5  [Support rules]
301
501
Half-It
Round the Clock
Standard Cricket
Count UP
[manual]
select play mode which you want
drag and slide to throw darts
[feature]
- Classic mode: Play the classic darts of the various rules
- Stage Mode: dart board with a variety of trick shots
- Multiplayer: Online War together with the world
- Invite a Friend: Invite your friends over for a possible war online
- Practice Mode: Practice mode for beginners darts
- Supports 16 countries language.
- Support achievements, leaderboard and invite friends.
- Supports multiplayer.
- Support tablet device.
- Offline mode support
Try the real challenge now 3D darts simulation!
Homepage :
https://play.google.com/store/apps/dev?id=4864673505117639552
Facebook :
https://www.facebook.com/mobirixplayen
YouTube :
https://www.youtube.com/user/mobirix1q'X   description_htmlq(B�  [Support rules]<br/>301<br/>501<br/>Half-It<br/>Round the Clock<br/>Standard Cricket<br/>Count UP<br/><br/>[manual]<br/>select play mode which you want<br/>drag and slide to throw darts<br/><br/>[feature]<br/>- Classic mode: Play the classic darts of the various rules<br/>- Stage Mode: dart board with a variety of trick shots<br/>- Multiplayer: Online War together with the world<br/>- Invite a Friend: Invite your friends over for a possible war online<br/>- Practice Mode: Practice mode for beginners darts<br/>- Supports 16 countries language.<br/>- Support achievements, leaderboard and invite friends.<br/>- Supports multiplayer.<br/>- Support tablet device.<br/>- Offline mode support<br/><br/>Try the real challenge now 3D darts simulation!<br/><br/>Homepage :<br/>https://play.google.com/store/apps/dev?id=4864673505117639552<br/><br/>Facebook : <br/>https://www.facebook.com/mobirixplayen<br/><br/>YouTube :<br/>https://www.youtube.com/user/mobirix1q)X   recent_changesq*NX   editors_choiceq+�X   priceq,X   0q-X   freeq.�X   iapq/�X   developer_idq0X   4864673505117639552q1X   updatedq2X   May 30, 2018q3X   sizeq4X   23Mq5X   installsq6X   10,000,000+q7X   current_versionq8X   1.1.6q9X   required_android_versionq:X
   4.1 and upq;X   content_ratingq<]q=X   Everyoneq>aX	   iap_rangeq?]q@X   Users Interact, Shares InfoqAaX   interactive_elementsqBh@X	   developerqCX   mobirixqDX   developer_emailqEX   help@mobirix.comqFX   developer_urlqGX&   https://www.facebook.com/mobirixplayenqHX   developer_addressqIXi   #901 9F JEI PLATZ, 186 ,Gasan digital 1-ro Geumcheon-gu Seoul, Republic of Korea
08502
ASI|KR|KS013|SEOULqJX   app_idqKX   com.mobirix.dartqLX   urlqMX>   https://play.google.com/store/apps/details?id=com.mobirix.dartqNX   bidsqOK�u.