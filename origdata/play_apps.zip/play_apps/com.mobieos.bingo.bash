�}q (X   titleqX   Bingo LottoqX   iconqXf   https://lh3.googleusercontent.com/PhvMtGy42p31pWF6WdELUr-3JXwy7u7gtd80k0zT-pzmik-wj_ejAV9ULRt6RWoaCLOHqX   screenshotsq]q(Xr   https://lh3.googleusercontent.com/jeDvkpfvAtHfdjmp7ICdqIvtptaR5pFnnennxcR20kv77VSXtTLBRT8K7RwAejkdkw8=w720-h310-rwqXr   https://lh3.googleusercontent.com/t5BYjHMjVr6ihVI1L68RNIuaHkDjX8QYsYSSwu1Ru8S3JAWPVTtmukylDvAYtWtxCZc=w720-h310-rwqXq   https://lh3.googleusercontent.com/w_0B_InbMZLIZ50TDnuEeWUwAqHrxtp7OtMMf-TuH3ppYkBcwEA23OmC6W9qsRiZRA=w720-h310-rwq	Xr   https://lh3.googleusercontent.com/q0ONMEvA0KjDwk3nePSm5pMyuguwF_c2v7sgNI7tPH4GoM0_hJCkNCfmVkQoYj4njic=w720-h310-rwq
Xq   https://lh3.googleusercontent.com/l2to7j609IJkt0nWfTunrVBwKI5e4Qe6Q4a8eYIOt-WRM80WXmj9d9PBAAOJi2N6Mg=w720-h310-rwqXq   https://lh3.googleusercontent.com/rrRTWKO-e5ER5oXazKb0fn1yHdA7l8RZiH_Paw96HUGdWgms6n8Uu4iCqkfERq1YCw=w720-h310-rwqXq   https://lh3.googleusercontent.com/wyPRcDjLtXHAeSR1D8fsZ40FErevhFATxBkh3dXyFh_fBI3_dLGGaVa3AAkI8DBgmA=w720-h310-rwqXr   https://lh3.googleusercontent.com/brVGxHmYbrMdLcPdpMa1PitF-eXZC9492t1VRRcyo39ptDSp1Xo1-BaU-mWB0J2RRSM=w720-h310-rwqXq   https://lh3.googleusercontent.com/05GGeWPfV_UuRUOE7RyBQC6bNbavaEo2j5eTKB6NKc_OYCxl3vrtbfVgSRNZKcQbKQ=w720-h310-rwqXr   https://lh3.googleusercontent.com/0LvNDD8jDWPlSyAOYFF5NGjSBPqFFSWfcVR52iIdddqWFWNxEumzCtkeGsGZvNGHoik=w720-h310-rwqXq   https://lh3.googleusercontent.com/ZkBEo6DUmkIgDTnRQn8JNEa7t8Dpmx96Oh1XXqDzJ3iqzOpho1333Fm1ueCqhXo1ag=w720-h310-rwqXr   https://lh3.googleusercontent.com/1NkPacqeTOrPtJzKWiRG3CejN9ZWadlchGQMDuyWPHyQLQlkZ21itj2_HgqK86pmd-0=w720-h310-rwqeX   videoqNX   categoryq]qX   GAME_CASINOqaX   scoreqX   4.1qX	   histogramq}q(KM�KK�KKpKK*KKluX   reviewsqM@X   descriptionqX=  Bingo Battle game features:
1. Cool Game Graphics that will keep you entertained.
2.
Bingo Battle!
Play multiplayer in one on one battle. One of its kind feature where you can challenge other players for the treasure. This is a multiplayer bingo challenge.
3.
Powers:
Cool Power Ups like free bingo pop daubs, instant bingo and special power ups are popped in the game.
4.
Multiple themes
like Classic Loteria, Pirates and our special Christmas Theme.
5.
Spin of Fortune:
Collect diamonds, fortune keys and coins in wheel of fortune mini game.
6.
Fidget Spinner Daub:
Play with the most exclusive daub.
7. Try your luck at Video Poker
Many more features will unfold in your game of bingo lotto journey. Bingo maths is a good game for kids.
Online
Free Bingo
is a game of chance. Compete with other online players in special head on multiplayer matches. Use boosters to bash and win against your opponent in online battle. Practice bingo which is just at a tap away from you. Play the best free bingo game with no internet or offline. Play bingo game for free with high payout winnings.qX   description_htmlqB�  Bingo Battle game features:<br/>1. Cool Game Graphics that will keep you entertained.<br/>2. <b>Bingo Battle! </b> Play multiplayer in one on one battle. One of its kind feature where you can challenge other players for the treasure. This is a multiplayer bingo challenge.<br/> 3. <b>Powers:</b> Cool Power Ups like free bingo pop daubs, instant bingo and special power ups are popped in the game.<br/>4. <b>Multiple themes</b> like Classic Loteria, Pirates and our special Christmas Theme.<br/>5. <b>Spin of Fortune: </b> Collect diamonds, fortune keys and coins in wheel of fortune mini game.<br/>6. <b>Fidget Spinner Daub:</b> Play with the most exclusive daub.<br/>7. Try your luck at Video Poker<br/><br/><br/>Many more features will unfold in your game of bingo lotto journey. Bingo maths is a good game for kids.<br/><br/>Online <b>Free Bingo</b> is a game of chance. Compete with other online players in special head on multiplayer matches. Use boosters to bash and win against your opponent in online battle. Practice bingo which is just at a tap away from you. Play the best free bingo game with no internet or offline. Play bingo game for free with high payout winnings.qX   recent_changesq NX   editors_choiceq!�X   priceq"X   0q#X   freeq$�X   iapq%�X   developer_idq&X    MobiEos+Software+Private+Limitedq'X   updatedq(X   September 1, 2018q)X   sizeq*X   31Mq+X   installsq,X   50,000+q-X   current_versionq.X   1.72q/X   required_android_versionq0X
   4.1 and upq1X   content_ratingq2]q3(X   Teenq4X   Simulated Gamblingq5eX	   iap_rangeq6X   $0.99q7X   $99.99q8�q9X   interactive_elementsq:]q;X   Digital Purchasesq<aX	   developerq=X    MobiEos Software Private Limitedq>X   developer_emailq?X   bingo@mobieos.comq@X   developer_urlqAX   http://www.mobieos.comqBX   developer_addressqCXK   Mobieos Software Private Limited.
#83/4, 13th Main,
Indiranagar,
Bangalore.qDX   app_idqEX   com.mobieos.bingo.bashqFX   urlqGXD   https://play.google.com/store/apps/details?id=com.mobieos.bingo.bashqHX   bidsqIM�u.