�}q (X   titleqX2   Video2me:Gif Maker App & Video to Gif&Gif to VideoqX   iconqXe   https://lh3.googleusercontent.com/Esc87sy2nmH_fk2Rej-zAvpspUySR2QLRoV7FEzP4woC0AKuWoE52vaTCahup8KsJ3EqX   screenshotsq]q(Xs   https://lh3.googleusercontent.com/N1kn54_5E2Zh1CGvgm6uDySON7i5jufWJ9UO-gkf1_QHyCyKDwta_f_T2mUlWhVAvgHh=w720-h310-rwqXq   https://lh3.googleusercontent.com/83XIQmVEvIOmB1fV1J-yCy9hvXMBlL-nKNxwWwHKPpZjNeaAiT8BFtC6BByL6tgufg=w720-h310-rwqXr   https://lh3.googleusercontent.com/FbG6bPF0Btk87PiaSItdpE5qpEJpov2RcBzYTSb4if-WNGKnwUvutY3lUiHX2s1KXXk=w720-h310-rwq	Xr   https://lh3.googleusercontent.com/Nk2AFl4FczvQp44TrS-kUcSVHtJWOEpRRLLM0VZhbnzx4fIaZMr66kVu6WZmSOxMufk=w720-h310-rwq
Xq   https://lh3.googleusercontent.com/GeSinhh_kEgpVUgyA7REY7ABLthdy2TnF92pSMQv3IrfiVvbRTqvRkfavyN6GPsr4A=w720-h310-rwqXr   https://lh3.googleusercontent.com/LrZZ3rn_nYNvkkUiW3ytxw6tsEYMtQpVBUAt2LxgjnFyyZAQF3yQWiRPS0ad0mkFD4M=w720-h310-rwqXr   https://lh3.googleusercontent.com/QVpeiHtWWHJcfemKH_SQI4F3ChxuuOMSUxIOanXpLllYh8eXqTaA-gbgxUd1Xwx9RBo=w720-h310-rwqXs   https://lh3.googleusercontent.com/Zi7EaEL4WEVgzzQPRKXe5mFggea0NhurYYE5iDQW8EQduL-Vs7CS2p_UUyYVNanRwZ1p=w720-h310-rwqeX   videoqNX   categoryq]qX   VIDEO_PLAYERSqaX   scoreqX   4.5qX	   histogramq}q(KM�BKMVKM�KM�KM�uX   reviewsqMu\X   descriptionqX�  All in one Video-Gif-Mp3-Picture Editor App, contains tons of editing & converting features. Don't miss this 4.5 rated amazing app...
Video Features:
Add text to video
Add sticker to video
Merge videos
Create video collage
Create slideshow
Create framed videos
Trim video
Convert video to gif
Convert gif to video
Decrease video size
Crop video
Capture image from video
Rotate video
Convert video to Instagram format (no crop)
Convert video to audio
Convert flv to mp4
Convert 3gp to mp4
Convert mkv to mp4
Convert webm to mp4
Convert avi to mp4
Create Boomerang,Reverse Video from Gif
Speed up Video
Slow Down Video
Mute Video
Gif Features:
Add text to gif
Add sticker to gif
Create gif from pictures
Create gif from camera
Convert video to gif
Convert gif to video
Capture image from gif
Reduce gif size
Rotate Gif
Crop Gif
Create Boomerang,Reverse Gif from Video
Speed up Gif
Slow Down Gif
Reverse Gif
Share Gif on Whatsapp
Photo Features:
Add text to picture
Add sticker to picture
Change photo brightness
Crop photo
Rotate photo
Use filters on photo
Convert photo to Instagram format (no crop)
Create framed photos
Music Features:
Convert Video to Music
Trim Mp3,Mp4
Change ringtone
Change default alarm sound
Change default notification sound
If you have any problems or suggestions please contact us at: androidae2015@gmail.com
Uses FFmpeg under permission of LGPL.
Special Features:
Video to gif maker with music
Gif to video maker with music
Gif to video instagram
Gif to video for instagram
Instagram gif to video
Video to gif post on instagram
Gif editor with text
Gif editor with music
Gif editor photo
Gif maker for instagram
Gif maker from picture
Gif maker app for whatsapp
Gif editor and maker with music
Gif maker free
Video editor with music
Video editor free
Video trimmer and editor
Video trimmer hd
Video trimmer and joiner
Video trimmer no watermark
Video to gift converter
Video to gif converter hd
Video to gif maker with sound
Video to gif maker app
App to convert photo into animated gif video
Gif to video converter hd
Gif converter to video
Gif maker free
To Video
Video to
To gif
Gif to
Gif to video app
Video to Gif app
Gif to video converter app
Video to gif converter app
Editor video editor
Editor video pro
Editor video with music and picture
Video to gif converter
Editor photo makeup
Editor photo apps
Editor photo editor
Editor photo apps 2018
Editor photo apps 2019
Editor de fotos para instagram
Editor de fotos profesional
Editor de fotos e videos
Editor de fotos tumblr
Baby Gif
Gif baby
Cat gif
Dog gif
Baby gifs
Dog gifs
Cat gifs
Baby gift
Baby gif for whatsapp
Baby gif wallpaper
Good morning baby gif
Cat gif wallpaper
Cat gift
Good morning cat gif
Funny cat gifs
Dog gifs
Funny dog gif
Trim Video
Trim Audio
Trim mp3
Trim mp4
Trim music
Trimmer app
Trimmer music
Trimmer mp3
Trimmer audio
Trimmer prank
Trimmer sound
Trimmer sound app
Mp3 trimmer
Audio trimmer
Music trimmer
Music trimmer and joiner
Music trimmer and editor
Music trimmer and merger
Mp3 trimmer and editor
Mp3 trimmer and merger
Audio trimmer and editor
Audio file trimmer
Audio editor and trimmer
Audio trimmer and joiner
Audio trimmer app
Audio trimmer and merger
Mp3 trimmer and editor
Mp3 trimmer and merger
Mp3 trimmer and joiner
Mp3 trimmer app
Reduce gif size
Decrease gif size
Add sound to gif
Gif to mp4
Gifs with sound
Reduce video size
Decrease video size
How to make a gif from a video
How to convert gif to video
How to convert video to gif
Video to animated gif
Video to gif photoshop
Create gif from video
How to create gif from video
Video to gif online
Gif maker from video
How to turn a video into a gif
Turn video into gif
Imgur video to gif
Turn gif into video
Gif video app
Gif maker online
Animated gif maker
Free gif maker
Gif Editor and Maker
Video Editor
Gif to video converter
Video to gif converterqX   description_htmlqB  All in one Video-Gif-Mp3-Picture Editor App, contains tons of editing &amp; converting features. Don't miss this 4.5 rated amazing app...<br/><br/><br/><br/>Video Features:<br/>Add text to video<br/>Add sticker to video<br/>Merge videos<br/>Create video collage<br/>Create slideshow<br/>Create framed videos<br/>Trim video<br/>Convert video to gif<br/>Convert gif to video<br/>Decrease video size<br/>Crop video<br/>Capture image from video<br/>Rotate video<br/>Convert video to Instagram format (no crop)<br/>Convert video to audio<br/>Convert flv to mp4<br/>Convert 3gp to mp4<br/>Convert mkv to mp4<br/>Convert webm to mp4<br/>Convert avi to mp4<br/>Create Boomerang,Reverse Video from Gif<br/>Speed up Video<br/>Slow Down Video<br/>Mute Video<br/><br/>Gif Features:<br/>Add text to gif<br/>Add sticker to gif<br/>Create gif from pictures<br/>Create gif from camera<br/>Convert video to gif<br/>Convert gif to video<br/>Capture image from gif<br/>Reduce gif size<br/>Rotate Gif<br/>Crop Gif<br/>Create Boomerang,Reverse Gif from Video<br/>Speed up Gif<br/>Slow Down Gif<br/>Reverse Gif<br/>Share Gif on Whatsapp<br/><br/>Photo Features:<br/>Add text to picture<br/>Add sticker to picture<br/>Change photo brightness<br/>Crop photo<br/>Rotate photo<br/>Use filters on photo<br/>Convert photo to Instagram format (no crop)<br/>Create framed photos<br/><br/>Music Features:<br/>Convert Video to Music<br/>Trim Mp3,Mp4<br/>Change ringtone<br/>Change default alarm sound<br/>Change default notification sound<br/><br/><br/>If you have any problems or suggestions please contact us at: androidae2015@gmail.com<br/><br/><br/>Uses FFmpeg under permission of LGPL.<br/><br/>Special Features:<br/>Video to gif maker with music<br/>Gif to video maker with music<br/>Gif to video instagram<br/>Gif to video for instagram<br/>Instagram gif to video<br/>Video to gif post on instagram<br/>Gif editor with text<br/>Gif editor with music<br/>Gif editor photo<br/>Gif maker for instagram<br/>Gif maker from picture<br/>Gif maker app for whatsapp<br/>Gif editor and maker with music<br/>Gif maker free<br/>Video editor with music<br/>Video editor free<br/>Video trimmer and editor<br/>Video trimmer hd<br/>Video trimmer and joiner<br/>Video trimmer no watermark<br/>Video to gift converter<br/>Video to gif converter hd<br/>Video to gif maker with sound<br/>Video to gif maker app<br/>App to convert photo into animated gif video<br/>Gif to video converter hd<br/>Gif converter to video<br/>Gif maker free<br/>To Video<br/>Video to<br/>To gif<br/>Gif to<br/>Gif to video app<br/>Video to Gif app<br/>Gif to video converter app<br/>Video to gif converter app<br/>Editor video editor<br/>Editor video pro<br/>Editor video with music and picture<br/>Video to gif converter<br/>Editor photo makeup<br/>Editor photo apps<br/>Editor photo editor<br/>Editor photo apps 2018<br/>Editor photo apps 2019<br/>Editor de fotos para instagram<br/>Editor de fotos profesional<br/>Editor de fotos e videos<br/>Editor de fotos tumblr<br/>Baby Gif<br/>Gif baby<br/>Cat gif<br/>Dog gif<br/>Baby gifs<br/>Dog gifs<br/>Cat gifs<br/>Baby gift<br/>Baby gif for whatsapp<br/>Baby gif wallpaper<br/>Good morning baby gif<br/>Cat gif wallpaper<br/>Cat gift<br/>Good morning cat gif<br/>Funny cat gifs<br/>Dog gifs<br/>Funny dog gif<br/>Trim Video<br/>Trim Audio<br/>Trim mp3<br/>Trim mp4<br/>Trim music<br/>Trimmer app<br/>Trimmer music<br/>Trimmer mp3<br/>Trimmer audio<br/>Trimmer prank<br/>Trimmer sound<br/>Trimmer sound app<br/>Mp3 trimmer<br/>Audio trimmer<br/>Music trimmer<br/>Music trimmer and joiner<br/>Music trimmer and editor<br/>Music trimmer and merger<br/>Mp3 trimmer and editor<br/>Mp3 trimmer and merger<br/>Audio trimmer and editor<br/>Audio file trimmer<br/>Audio editor and trimmer<br/>Audio trimmer and joiner<br/>Audio trimmer app<br/>Audio trimmer and merger<br/>Mp3 trimmer and editor<br/>Mp3 trimmer and merger<br/>Mp3 trimmer and joiner<br/>Mp3 trimmer app<br/>Reduce gif size<br/>Decrease gif size<br/>Add sound to gif<br/>Gif to mp4<br/>Gifs with sound<br/>Reduce video size<br/>Decrease video size<br/>How to make a gif from a video<br/>How to convert gif to video<br/>How to convert video to gif<br/>Video to animated gif<br/>Video to gif photoshop<br/>Create gif from video<br/>How to create gif from video<br/>Video to gif online<br/>Gif maker from video<br/>How to turn a video into a gif<br/>Turn video into gif<br/>Imgur video to gif<br/>Turn gif into video<br/>Gif video app<br/>Gif maker online<br/>Animated gif maker<br/>Free gif maker<br/>Gif Editor and Maker<br/>Video Editor<br/>Gif to video converter<br/>Video to gif converterqX   recent_changesqNX   editors_choiceq�X   priceqX   0qX   freeq �X   iapq!�X   developer_idq"X   3A2E+Studioq#X   updatedq$X   September 25, 2018q%X   sizeq&X   26Mq'X   installsq(X
   1,000,000+q)X   current_versionq*X   1.5.16q+X   required_android_versionq,X
   4.4 and upq-X   content_ratingq.]q/X   Everyoneq0aX	   iap_rangeq1X   $0.99q2X   $9.99q3�q4X   interactive_elementsq5NX	   developerq6X   3A2E Studioq7X   developer_emailq8X   androidae2015@gmail.comq9X   developer_urlq:X4   http://androidae2015.blogspot.com.tr/p/video2me.htmlq;X   developer_addressq<XR   İTÜ Ayazağa Kampüsü, Teknokent ARI4 Binası
34469,Maslak / İstanbul Türkiyeq=X   app_idq>X   tr.com.ea.a.a.mmq?X   urlq@X>   https://play.google.com/store/apps/details?id=tr.com.ea.a.a.mmqAX   bidsqBK4u.